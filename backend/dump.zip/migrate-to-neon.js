/**
 * migrate-to-neon.js
 * Direct, Foreign-Key safe data transfer from Local Postgres to Neon
 */
require('dotenv').config();
const { Client } = require('pg');

// Neon Cloud connection
const NEON_DATABASE_URL =
  'postgresql://neondb_owner:npg_Im1ByUC6NhwM@ep-odd-hat-b5rioeon-pooler.c-7.us-east-2.aws.neon.tech/neondb?sslmode=require';

// Local Database URL (reads from local .env or fallback)
const LOCAL_DATABASE_URL =
  process.env.LOCAL_DATABASE_URL ||
  "postgresql://postgres:Letif7327@localhost:5432/b2b_retail_db?schema=public";

// Strict transfer order: Parents before Children
const ORDERED_TABLES = [
  'users',
  'categories',
  'products',
  'orders',
  'order_items',
  'banners',
  'ledger_entries',
  'otp_verifications',
];

async function transfer() {
  const local = new Client({ connectionString: LOCAL_DATABASE_URL });
  const neon = new Client({
    connectionString: NEON_DATABASE_URL,
    ssl: { rejectUnauthorized: false },
  });

  try {
    console.log('🔌 Connecting to Local PostgreSQL and Neon Cloud...');
    await local.connect();
    await neon.connect();
    console.log('✅ Connected to both databases!\n');

    for (const table of ORDERED_TABLES) {
      // 1. Fetch data from local
      let localRows = [];
      try {
        const res = await local.query(`SELECT * FROM "${table}"`);
        localRows = res.rows;
      } catch (err) {
        console.log(`⏩ Table "${table}" does not exist in local DB, skipping.`);
        continue;
      }

      if (localRows.length === 0) {
        console.log(`ℹ️  "${table}": 0 rows locally (skipping)`);
        continue;
      }

      console.log(`📦 Copying ${localRows.length} rows for "${table}"...`);

      // 2. Insert into Neon row by row
      for (const row of localRows) {
        const columns = Object.keys(row);
        const colNames = columns.map((c) => `"${c}"`).join(', ');
        const placeholders = columns.map((_, i) => `$${i + 1}`).join(', ');
        const values = Object.values(row);

        // Build ON CONFLICT clause for tables with an "id" or "phone_number"
        let conflictClause = 'ON CONFLICT DO NOTHING';
        if (columns.includes('id')) {
          const updateAssignments = columns
            .filter((c) => c !== 'id')
            .map((c) => `"${c}" = EXCLUDED."${c}"`)
            .join(', ');

          if (updateAssignments.length > 0) {
            conflictClause = `ON CONFLICT ("id") DO UPDATE SET ${updateAssignments}`;
          }
        }

        const query = `
          INSERT INTO "${table}" (${colNames}) 
          VALUES (${placeholders}) 
          ${conflictClause};
        `;

        try {
          await neon.query(query, values);
        } catch (insertErr) {
          console.error(`   ❌ Error inserting into ${table}:`, insertErr.message);
        }
      }

      console.log(`   ✅ "${table}" transferred successfully.`);
    }

    console.log('\n🎉 ALL LOCAL DATA SUCCESSFULLY COPIED TO NEON!\n');
  } catch (err) {
    console.error('Fatal transfer error:', err);
  } finally {
    await local.end().catch(() => {});
    await neon.end().catch(() => {});
  }
}

transfer();