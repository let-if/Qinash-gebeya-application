/**
 * verify-data.js
 * Side-by-side row count comparison between Local and Neon
 */
require('dotenv').config();
const { Client } = require('pg');

const NEON_DATABASE_URL =
  'postgresql://neondb_owner:npg_Im1ByUC6NhwM@ep-odd-hat-b5rioeon-pooler.c-7.us-east-2.aws.neon.tech/neondb?sslmode=require';

// Replace with your local connection string if different
const LOCAL_DATABASE_URL = 'postgresql://postgres:Letif7327@localhost:5432/b2b_retail_db';

async function verify() {
  const localClient = new Client({ connectionString: LOCAL_DATABASE_URL });
  const neonClient = new Client({
    connectionString: NEON_DATABASE_URL,
    ssl: { rejectUnauthorized: false },
  });

  try {
    await localClient.connect();
    await neonClient.connect();

    console.log('📊 Comparing Database Row Counts:\n');
    console.log(
      '------------------------------------------------------------------'
    );
    console.log(
      `${'Table Name'.padEnd(25)} | ${'Local DB'.padEnd(12)} | ${'Neon Cloud'.padEnd(12)} | Status`
    );
    console.log(
      '------------------------------------------------------------------'
    );

    const { rows: tables } = await neonClient.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
        AND table_type = 'BASE TABLE'
        AND table_name != '_prisma_migrations';
    `);

    for (const { table_name } of tables) {
      let localCount = 0;
      let neonCount = 0;

      try {
        const resLocal = await localClient.query(
          `SELECT COUNT(*) FROM "${table_name}"`
        );
        localCount = parseInt(resLocal.rows[0].count, 10);
      } catch (e) {
        localCount = 'N/A';
      }

      try {
        const resNeon = await neonClient.query(
          `SELECT COUNT(*) FROM "${table_name}"`
        );
        neonCount = parseInt(resNeon.rows[0].count, 10);
      } catch (e) {
        neonCount = 'Error';
      }

      const match =
        localCount === neonCount
          ? '✅ Match'
          : localCount === 0 && neonCount === 0
          ? '⚪ Empty'
          : '⚠️ Mismatch';

      console.log(
        `${table_name.padEnd(25)} | ${String(localCount).padEnd(12)} | ${String(
          neonCount
        ).padEnd(12)} | ${match}`
      );
    }
    console.log(
      '------------------------------------------------------------------\n'
    );
  } catch (err) {
    console.error('Inspection error:', err.message);
  } finally {
    await localClient.end().catch(() => {});
    await neonClient.end().catch(() => {});
  }
}

verify();